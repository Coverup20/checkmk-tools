#!/usr/bin/env bash
set -euo pipefail

echo "=== Configurazione retention backup Checkmk ==="

# Mi assicuro di avere curl (Postfix già installato al 25)
apt-get install -y curl

# Salvo lo script direttamente in /usr/local/bin/
cat > /usr/local/bin/checkmk-backup-cleanup.sh <<'EOF'
#!/bin/bash
# Script per retention dei backup Checkmk (14 giorni) con notifica Telegram + mail

BACKUP_DIR="/var/backups/checkmk"
DATE_NOW="$(date '+%Y-%m-%d %H:%M:%S')"

# --- PULIZIA ---
FILES_DELETED=$(find "$BACKUP_DIR" -type f \( -name "backup-*.tar" -o -name "backup-*.tar.gz" \) -mtime +14 -print -delete | wc -l)
DIRS_DELETED=$(find "$BACKUP_DIR" -type d -name "Check_MK-*" -mtime +14 -print -exec rm -rf {} \; | wc -l)

# --- SUMMARY ---
SUMMARY="Checkmk Backup Retention

Path: $BACKUP_DIR
Data: $DATE_NOW

File eliminati: $FILES_DELETED
Directory eliminate: $DIRS_DELETED"

# --- TELEGRAM ---
TOKEN="8264716040:AAHPjzYJz7h8pV9hzjaf45-Mrv2gf8tMXmQ"
CHAT_ID="381764604"

curl -s -X POST "https://api.telegram.org/bot${TOKEN}/sendMessage" \
     -d chat_id="${CHAT_ID}" \
     -d text="${SUMMARY}" >/dev/null 2>&1

# --- MAIL ---
MAIL_TO="marzio@nethesis.it"
echo -e "$SUMMARY" | mail -s "Checkmk Backup Retention Report" "$MAIL_TO"

echo "$SUMMARY"
EOF

# Rendo eseguibile
chmod +x /usr/local/bin/checkmk-backup-cleanup.sh

# Configuro cron se non esiste già

# Configuro cron per root
CRON_JOB="30 3 * * * /usr/local/bin/checkmk-backup-cleanup.sh >> /var/log/checkmk-backup-cleanup.log 2>&1"

# Leggo la crontab di root (se non esiste, creo un file vuoto)
TMP_CRON=$(mktemp)
sudo crontab -l -u root 2>/dev/null > "$TMP_CRON" || true

# Aggiungo la riga solo se non già presente
if ! grep -q "/usr/local/bin/checkmk-backup-cleanup.sh" "$TMP_CRON"; then
    echo "$CRON_JOB" >> "$TMP_CRON"
    sudo crontab -u root "$TMP_CRON"
    echo "✅ Cron job aggiunto alla crontab di root"
else
    echo "ℹ️  Cron job già presente"
fi

rm -f "$TMP_CRON"

echo "Retention backup configurata."
