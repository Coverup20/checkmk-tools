#!/usr/bin/env bash
set -euo pipefail

apt-get update -y
apt-get install -y certbot

WS="${WEBSERVER:-apache}"
case "$WS" in
  apache)
    apt-get install -y apache2 python3-certbot-apache
    ;;
  nginx)
    apt-get install -y nginx python3-certbot-nginx
    ;;
  standalone)
    ;;
  *)
    echo "Valore WEBSERVER non valido: $WS (usa apache|nginx|standalone)"
    exit 1
    ;;
esac

if [[ -n "${LETSENCRYPT_EMAIL:-}" || -n "${LETSENCRYPT_DOMAINS:-}" ]]; then
  mkdir -p /etc/letsencrypt
  CLI_INI="/etc/letsencrypt/cli.ini"
  {
    [[ -n "${LETSENCRYPT_EMAIL:-}" ]] && echo "email = ${LETSENCRYPT_EMAIL}"
    [[ -n "${LETSENCRYPT_DOMAINS:-}" ]] && echo "# domains = ${LETSENCRYPT_DOMAINS}"
    echo "agree-tos = true"
    echo "non-interactive = true"
  } > "$CLI_INI"
fi

echo "✅ Certbot installato."

# --- Parte interattiva ---
read -rp "Vuoi eseguire subito la challenge per generare i certificati? (y/n): " ANSW
if [[ "$ANSW" =~ ^[Yy]$ ]]; then
    if [[ -z "${LETSENCRYPT_DOMAINS:-}" ]]; then
        read -rp "Inserisci i domini separati da virgola (esempio: example.com,www.example.com): " DOMAINS
    else
        DOMAINS="$LETSENCRYPT_DOMAINS"
    fi

    case "$WS" in
      apache)
        certbot --apache -d "$DOMAINS"
        ;;
      nginx)
        certbot --nginx -d "$DOMAINS"
        ;;
      standalone)
        certbot certonly --standalone -d "$DOMAINS"
        ;;
    esac

    echo "✅ Certificati generati per: $DOMAINS"
else
    echo "ℹ️ Challenge saltata, puoi lanciarla manualmente con certbot in seguito."
fi
